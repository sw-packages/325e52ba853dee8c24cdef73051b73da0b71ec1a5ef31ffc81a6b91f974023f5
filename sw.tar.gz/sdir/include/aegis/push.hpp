//
// push.hpp
// ********
//
// Copyright (c) 2020 Sharon Fox (sharon at xandium dot io)
//
// Distributed under the MIT License. (See accompanying file LICENSE)
// 

#ifdef WIN32
# pragma warning(push)
# pragma warning(disable:4244)
# pragma warning(disable:4267)
#endif
