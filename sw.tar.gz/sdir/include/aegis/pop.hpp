//
// pop.hpp
// *******
//
// Copyright (c) 2020 Sharon Fox (sharon at xandium dot io)
//
// Distributed under the MIT License. (See accompanying file LICENSE)
// 

#ifdef WIN32
# pragma warning(pop)
#endif
